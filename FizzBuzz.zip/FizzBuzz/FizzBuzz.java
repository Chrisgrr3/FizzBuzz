public class FizzBuzz {
    public String fizzBuzz(int number) {
        if(number%3 == 0) {
            if( number %5 ==0) {
                String output = "FizzBuzz";
                return output;
            }
            else{
                String output = "Fizz";
                return output;
            }
        }
        else if(number%5 == 0) {
            String output = "Buzz";
            return output;
        }
        else{
            String output = Integer.toString(number);
            return output;
        }
    }
}